//
//  registervcViewController.swift
//  abcsad
//
//  Created by Arpan Dua on 21/02/18.
//  Copyright © 2018 ASD. All rights reserved.
//

import UIKit

class registervcViewController: UIViewController {

    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationItem.title = "Register"
        
        
        let buttonsubmit = UIBarButtonItem(title: "Submit", style: .plain, target: self, action: #selector(displayValues))
    
    self.navigationItem.rightBarButtonItem = buttonsubmit
        
    }
    
    
    @objc private func displayValues()
    {
        let infoalert = UIAlertController(title: "verify", message: "please verify your details", preferredStyle: .alert)
        
        infoalert.addAction(UIAlertAction(title: "Confirm", style: .default, handler: {_ in self.displayWelcomeScreen()}))
        
        
        self.present(infoalert, animated: true)
        
    }
    
    
    func displayWelcomeScreen()
    {
        let welcomesb : UIStoryboard = UIStoryboard(name: "main", bundle: nil)
        let welcomevc = welcomesb.instantiateViewController(withIdentifier: "welcome screen")
        
        
        navigationController?.pushViewController(welcomevc,animated: true)
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
