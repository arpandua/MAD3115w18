//
//  ViewController.swift
//  abcsad
//
//  Created by Arpan Dua on 21/02/18.
//  Copyright © 2018 ASD. All rights reserved.
//

import UIKit

class loginvc: UIViewController {

    
    
    
    @IBOutlet weak var labelpass: UILabel!
    
    @IBOutlet weak var labelemail: UILabel!
    
    
    
    @IBOutlet weak var login: UITextField!
    
    
    
    @IBOutlet weak var passtext: UITextField!
    
    
    
    
    
    @IBAction func regaction(_ sender: UIBarButtonItem) {
    
    
    
        let regsb : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        
        let regvc = regsb.instantiateViewController(withIdentifier: "reg123")
        
        navigationController?.pushViewController(regvc, animated: true)
        
    
    }
 
    
    
    
    
    
    
    
    
    
    @IBAction func loginaction(_ sender: UIBarButtonItem) {
    
        
        let email = login.text
        let password = passtext.text
        if(email == "test" && password == "test")
        {
            let infoalert =
                UIAlertController(title: "login successful", message: "you are authenticated", preferredStyle: .alert)
            
            
            infoalert.addAction(UIAlertAction(title: "ok", style: .default, handler: nil))
            
            self.present(infoalert, animated: true, completion: nil)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    }

