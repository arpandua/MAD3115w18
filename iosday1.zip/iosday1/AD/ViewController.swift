//
//  ViewController.swift
//  AD
//
//  Created by Arpan Dua on 20/02/18.
//  Copyright © 2018 ASD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var button: UIButton!
    
    
    @IBAction func loginbutton(_ sender: UIButton) {
        
        let email = textemailid.text!
        text.text = email
        
        let infoalert = UIAlertController(title: "User Info", message: textemailid.text!, preferredStyle: .actionSheet)
        
        infoalert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        self.present(infoalert, animated: true, completion: nil)
        
        
    }
    
    @IBOutlet weak var textemailid: UITextField!
    @IBOutlet weak var labelemailid: UILabel!
    @IBOutlet weak var text: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

