//
//  webpageVC.swift
//  Day3_23Feb
//
//  Created by Arpan Dua on 26/02/18.
//  Copyright © 2018 Kirandeep. All rights reserved.
//

import UIKit

class webpageVC: UIViewController {

    
    
    
    
    
    @IBOutlet weak var webview: UIWebView!
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadwebpage()
        print("Called loadwebpage")
        
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
func loadwebpage()
{
    let url = NSURL (string: "https://www.google.ca");
    let reqobj = NSURLRequest(url: url! as URL);
    webview.loadRequest(reqobj as URLRequest);
}
    
    
    
    func loadmanualpage()
    {
        let localfilepath = Bundle.main.url(forResource: "pizza", withExtension: "html")
        let myreq = NSURLRequest(url: localfilepath!);
        webview.loadRequest(myreq as URLRequest);
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
