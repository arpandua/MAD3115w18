//
//  MenuItems.swift
//  Day3_23Feb
//
//  Created by MacStudent on 2018-02-23.
//  Copyright © 2018 Kirandeep. All rights reserved.
//

import Foundation
class MenuItems{
    let names: [String] = ["Chicken","Tuna Sub","Turkey","Ham","Pepproni","Salami","Italian BMT","MeatBalls","Teriyaki","Roasted Chicken","Steak","Spicy Italian","Vegie"]
    let prices:[Double] = [23.4 , 12.3 , 12.5, 7.49, 6.79, 8.89, 5.89, 9.38, 6.89, 7.89, 8.67, 6.67, 7.89, 9.90]
    let specials:[Bool] = [false, true, false, true, false, true, false, true, false, true, false, true, false, true]
    
    
    
}
