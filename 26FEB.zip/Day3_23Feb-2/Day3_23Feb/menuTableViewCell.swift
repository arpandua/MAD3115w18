//
//  menuTableViewCell.swift
//  Day3_23Feb
//
//  Created by MacStudent on 2018-02-23.
//  Copyright © 2018 Kirandeep. All rights reserved.
//

import UIKit

class menuTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
